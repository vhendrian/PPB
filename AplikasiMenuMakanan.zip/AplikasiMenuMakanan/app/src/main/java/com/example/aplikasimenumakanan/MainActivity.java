package com.example.aplikasimenumakanan;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{

    private final ArrayList<String> fotoMakanan = new ArrayList<>();
    private final ArrayList<String> namaMakanan = new ArrayList<>();
    private final ArrayList<String> infoMakanan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDataFromInternet();
    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(fotoMakanan, namaMakanan, infoMakanan, this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void getDataFromInternet(){
        namaMakanan.add("Soto Ayam Semarang");
        fotoMakanan.add("https://akcdn.detik.net.id/community/media/visual/2021/06/24/resep-soto-ayam-semarang_43.jpeg");
        infoMakanan.add("Soto ayam Semarang yang berkuah bening gurih selalu enak dimakan kapan saja. Kaldunya kekuningan dengan taburan bawang putih goreng membuat rasanya makin sedap.\n" +
                "\n" +
                "Baca artikel detikfood, \"Resep Soto Ayam Semarang Kuah Bening yang Gurih Segar\" selengkapnya https://food.detik.com/ayam/d-5618028/resep-soto-ayam-semarang-kuah-bening-yang-gurih-segar.\n" +
                "\n" +
                "Download Apps Detikcom Sekarang https://apps.detik.com/detik/");

        namaMakanan.add("Tahu Gimbal");
        fotoMakanan.add("https://upload.wikimedia.org/wikipedia/id/thumb/f/f7/Tahu_Gimbal_Semarang.jpg/220px-Tahu_Gimbal_Semarang.jpg");
        infoMakanan.add("Makanan ini terdiri dari tahu goreng, rajangan kol mentah, lontong, taoge, telur, dan gimbal (udang yang digoreng dengan tepung) dan dicampur dengan bumbu kacang yang khas karena menggunakan petis udang. Beda dengan saus kacang untuk pecel Madiun yang agak kental. Saus bumbu kacang untuk tahu gimbal agak sedikit encer.");

        namaMakanan.add("Wingko Babat");
        fotoMakanan.add("https://cdnt.orami.co.id/unsafe/468x397/cdn-cas.orami.co.id/parenting/images/2_O5LWOa4.width-800.jpg");
        infoMakanan.add("Wingko Babat adalah makanan khas Indonesia yang terbuat dari kelapa muda, tepung beras dan gula. Makanan yang satu ini paling banyak terdapat di Pantai Utara Pulau Jawa.");

        namaMakanan.add("Nasi Goreng Babat");
        fotoMakanan.add("https://akcdn.detik.net.id/community/media/visual/2016/10/09/6475882d-4ffb-4c7e-9531-090753abd370_169.jpg");
        infoMakanan.add("Nasi goreng khas Semarang ini memakai babat sapi yang kenyal empuk. Ditambah sambal dan kecap manis.\n" +
                "\n" +
                "Baca artikel detikfood, \"Babat Gongso Jadi Paduan Unik Nasi Goreng Khas Semarang\" selengkapnya https://food.detik.com/info-kuliner/d-3316483/babat-gongso-jadi-paduan-unik-nasi-goreng-khas-semarang.\n" +
                "\n" +
                "Download Apps Detikcom Sekarang https://apps.detik.com/detik/");

        namaMakanan.add("Loenpia");
        fotoMakanan.add("https://img.kurio.network/k4i9H75TrLYVzAXvnHhJ-eOz0pc=/1200x900/filters:quality(80)/https://kurio-img.kurioapps.com/20/10/13/29a1a2bc-7a57-4997-8121-7c2ce9855a05.jpeg");
        infoMakanan.add("Lumpia merupakan makanan khas Semarang yang merupakan perpaduan budaya Jawa dan China.");

        prosesRecyclerViewAdapter();
    }

}